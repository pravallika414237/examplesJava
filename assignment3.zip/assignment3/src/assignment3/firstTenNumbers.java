package assignment3;

public class firstTenNumbers {

	public static void main(String[] args) {
		System.out.println("First ten numbers :");
		
		for(int i=1;i<=10;i++) {
			System.out.print(i+" ");
		}
	}

}
