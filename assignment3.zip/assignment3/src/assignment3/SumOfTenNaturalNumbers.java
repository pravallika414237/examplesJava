package assignment3;

public class SumOfTenNaturalNumbers {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
System.out.println("Sum of First ten Natural numbers :");
		int sum=0;
		for(int i=1;i<=10;i++) {
			sum=sum+i;
			
		}
		System.out.print(sum);
	}

}
