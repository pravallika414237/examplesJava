package assignment2;

public class MultiplesOfThreeFiveFifteen {

	public static void main(String[] args) {
		System.out.println("NUMBERS DIVISIBLE BY 15 FROM 1 TO 100 : ");
		for(int i=1;i<100;i++) {
			if(i%3==0  &&   i %5==0) {
				
				System.out.print(i +",");
			}}
		System.out.println("\n NUMBERS DIVISIBLE BY 3 FROM 1 TO 100 : ");
		for(int i=1;i<100;i++) {
			if(i%3==0) {
				
				System.out.print(i+",");
			}}
		System.out.println("\n NUMBERS DIVISIBLE BY 3 FROM 1 TO 100 : ");
		for(int i=1;i<100;i++) {
			if(i %5==0) {
				//System.out.println("NUMBERS DIVISIBLE BY 5 FROM 1 TO 100 : ");
				System.out.print(i+",");
			}
		}}

	}


